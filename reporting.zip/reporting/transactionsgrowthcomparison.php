<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json"); 
header("Access-Control-Allow-Headers: *");

// Define the number of data points and series
$numDataPoints = 24;
$numSeries = 2;

// Initialize an array to store series data
$series = [
    "previousLabel" =>  "2021",
    "currentLabel" =>  "2022",
    "data" => [],
    "totals" => [
       ["label" => "2021", "value" => rand(10000, 99999999)],
       ["label" => "2022", "value" => rand(10000, 99999999)],
    ],
    "totalGrowth" =>  rand(10, 999)
];

// Generate random data for each series
$currentDate = new DateTime();

for ($j = 0; $j < $numDataPoints; $j++) {
    $hourDate = clone $currentDate;
    $hourDate->setTime($j, 0, 0);
    $label = $j == 0 ? "12am":( $j < 12 ? $j."am": ($j-12)."pm");
    $dataPoint = [
        "label" => $label, // Generate random values for the data points
        "growth"=> rand(10, 999),
        "previousValue"=> rand(1000, 99999),
        "currentValue"=> rand(1000, 99999),
    ];

    array_push($series["data"], $dataPoint);
}

// Return the employee data as JSON
echo json_encode($series, JSON_PRETTY_PRINT);
?>