<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json"); 
header("Access-Control-Allow-Headers: *");

$payment = ["CardNotPresent","PrivateLabel","InstantEFT"];
//shuffle($payment);

// Return the employee data as JSON
echo json_encode($payment, JSON_PRETTY_PRINT);
?>