<?php
header("Access-Control-Allow-Origin: *");
header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Headers: *");

$summary = [
    "volume"=> rand(1000000000000, 9999999999999),
    "value"=> rand(100000000, 999999999),
    "maximumValue"=> rand(1000000000000, 9999999999999),
    "averageValue"=> rand(10000, 99999),
    "quickestTimeInMs"=> rand(10, 100),
    "averageVolumePerMinute"=> rand(10, 99),
    "maximumVolumePerSecond"=> rand(10, 99)
];

// Return the employee data as JSON
echo json_encode($summary, JSON_PRETTY_PRINT);
?>