<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json"); 
header("Access-Control-Allow-Headers: *");

// Define the number of data points and series
$numDataPoints = 24;
$numSeries = 1;

// Generate random data for each series
$currentDate = new DateTime();
$series = [];
for ($j = 0; $j < $numDataPoints; $j++) {
    $hourDate = clone $currentDate;
    $hourDate->setTime($j, 0, 0);
    $dataPoint = [
        "label" => $j, // Generate random values for the data points
        "value" => rand(1000, 10000) // Generate random values for the data points
    ];

    array_push($series, $dataPoint);
}

// Return the employee data as JSON
echo json_encode($series, JSON_PRETTY_PRINT);
?>